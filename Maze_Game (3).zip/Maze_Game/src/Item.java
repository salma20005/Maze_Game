public abstract class Item {

    public abstract int UseEffect();

}

